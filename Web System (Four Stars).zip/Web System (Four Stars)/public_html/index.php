<?php
header("Location: top_ideas.php");
exit();
?>

<?php
#include_once "./footer.php";
?>

